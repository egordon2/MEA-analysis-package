
#' @title Input dataset for create_electrode_dataset MEA parameter function.
#'
#' @description A data set containing electrode burst list data produced by the axis navigator tool.
#'
#'
#' @format ## `
#' \describe{
#'   ...
#' }
#' @source <https://www.github.com/egordon2/MEAanalysis>
