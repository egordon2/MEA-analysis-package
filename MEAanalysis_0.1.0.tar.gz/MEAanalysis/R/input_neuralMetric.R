
#' @title Input dataset for create_synchrony_dataset parameter function.
#'
#' @description A data set containing neural metric data produced by the neural metric tool (axis navigator software).
#'
#' @source <https://www.github.com/egordon2/MEAanalysis>
